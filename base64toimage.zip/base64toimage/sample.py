import openpyxl
import pandas as pd

data1 = pd.read_excel(r'New_Query_2022_03_10.xlsx',engine='openpyxl')

# data1 = pd.read_excel(r'New_Query_2022_03_16 (1).xlsx',engine='openpyxl')

from  tqdm import tqdm
import base64

for index, url in tqdm(enumerate(data1.iloc[:,7])):
    if not isinstance(url,float) and 'http' not in url:
        # print(url)
        try:
            url_lits = url.split(';')
            image_type = url_lits[0].split(':')[1].split('/')[1]
            baseb4_value = url_lits[1].split(',')[1]
            baseb4_value = bytes(baseb4_value, 'utf-8')
            image_64_decode = base64.decodestring(baseb4_value) 
            image_result = open(f'image/{data1.iloc[index,0]}.{image_type}', 'wb') # create a writable image and write the decoding result
            image_result.write(image_64_decode)
        except: pass